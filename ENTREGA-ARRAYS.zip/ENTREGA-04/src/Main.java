
public class Main {

	public static void main(String[] args) {
		
		Nomes objNomes = new Nomes();
		objNomes.listarNomes();
	}
}
