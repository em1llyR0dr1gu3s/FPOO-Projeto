package valores;

public class Main {
	public static void main(String[] args) {
		
		Valores objNumero = new Valores();
		objNumero.ValoresNumericos();

	}

}
